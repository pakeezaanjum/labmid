/*
Lab 4 symbol table.

Keep this header file in the same folder as translator.l.
The active table represents the current block.
prev points to the parent block's table.
put() inserts a declaration in the current table only.
get() searches the current table and then parent tables.
*/

#ifndef SYMTAB_H
#define SYMTAB_H

#include <string>
#include <map>
using namespace std;

struct sym_ent {
    string type;
};

class sym_tab {
public:
    map<string, sym_ent*> table;
    sym_tab *prev;

    sym_tab(sym_tab *p) {
        prev = p;
    }

    bool put(string name, sym_ent *symbol) {
        if (table.count(name) == 0) {
            table[name] = symbol;
            return true;
        }
        return false;
    }

    sym_ent *get(string name) {
        for (sym_tab *p = this; p != NULL; p = p->prev) {
            if (p->table.count(name) > 0)
                return p->table[name];
        }
        return NULL;
    }

    ~sym_tab() {
        for (auto item : table)
            delete item.second;
    }
};

#endif
