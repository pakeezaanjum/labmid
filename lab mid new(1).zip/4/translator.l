/*
Task: Add declarations and nested scopes to the assignment parser.

Input example:
{
    int x;
    int y;
    x = 2 + 3 * 4;
    {
        float x;
        x = 5 + 10;
    }
    y = 4 + x;
}

Exam approach:
1. Keep symtab.h and translator.l in the same folder.
2. Create a new symbol table when entering a block.
3. Link the new table to its parent using prev.
4. Insert declared names in the current table using put().
5. Search current and parent scopes using get().
6. Delete the inner table and restore the parent when leaving the block.
7. Parse assignments using the same expression functions from Lab 3.

Commands:
flex translator.l
g++ lex.yy.c -o translator
./translator input.txt
*/

%option noyywrap

%{
#include <iostream>
#include <cstdlib>
#include <cstdio>
#include <string>
#include "symtab.h"
using namespace std;

const int T_TYPE = 350;
const int T_ID = 351;
const int T_NUM = 352;

sym_tab *top = NULL;
int lookahead;
int line = 1;

void match(int);
void error();
void program();
void block();
void decls();
void decl();
void stmts();
void stmt();
void expr();
void expr2();
void term();
void term2();
void factor();
%}

LETTER [A-Za-z_]
DIGIT [0-9]
IDPAT {LETTER}({LETTER}|{DIGIT})*

%%

[ \t\r]+                    ;
\n                          { line++; }
"int"|"float"|"bool"|"char" { return T_TYPE; }
{IDPAT}                     { return T_ID; }
{DIGIT}+                    { return T_NUM; }
.                           { return yytext[0]; }

%%

int main(int argc, char *argv[])
{
    if (argc == 2)
        yyin = fopen(argv[1], "r");

    lookahead = yylex();
    program();

    if (lookahead != 0)
        error();

    return 0;
}

void match(int token)
{
    if (lookahead == token)
        lookahead = yylex();
    else
        error();
}

void error()
{
    cerr << "Syntax error on line " << line << endl;
    exit(1);
}

void program()
{
    block();
}

void block()
{
    match('{');

    sym_tab *saved = top;
    top = new sym_tab(top);

    decls();
    stmts();

    match('}');

    delete top;
    top = saved;
}

void decls()
{
    while (lookahead == T_TYPE)
        decl();
}

void decl()
{
    string type(yytext);
    match(T_TYPE);

    string name(yytext);
    match(T_ID);
    match(';');

    sym_ent *entry = new sym_ent;
    entry->type = type;

    if (!top->put(name, entry)) {
        cerr << "Multiple declarations of " << name << endl;
        delete entry;
    }
}

void stmts()
{
    while (lookahead == T_ID || lookahead == '{')
        stmt();
}

void stmt()
{
    if (lookahead == '{') {
        block();
    }
    else if (lookahead == T_ID) {
        string name(yytext);
        match(T_ID);

        sym_ent *entry = top->get(name);
        if (entry == NULL)
            cerr << "Undeclared variable " << name << endl;

        match('=');
        expr();
        match(';');
    }
    else {
        error();
    }
}

void expr()
{
    term();
    expr2();
}

void expr2()
{
    if (lookahead == '+') {
        match('+');
        term();
        expr2();
    }
}

void term()
{
    factor();
    term2();
}

void term2()
{
    if (lookahead == '*') {
        match('*');
        factor();
        term2();
    }
}

void factor()
{
    if (lookahead == T_ID) {
        string name(yytext);
        match(T_ID);

        if (top->get(name) == NULL)
            cerr << "Undeclared variable " << name << endl;
    }
    else if (lookahead == T_NUM) {
        match(T_NUM);
    }
    else if (lookahead == '(') {
        match('(');
        expr();
        match(')');
    }
    else {
        error();
    }
}
