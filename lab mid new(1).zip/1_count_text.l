/*
Task: Count characters, words and lines in a text file.

Exam approach:
1. Make counters for characters, words and lines.
2. Match a word as one or more non-whitespace characters.
3. Add yyleng to the character count.
4. Count spaces and tabs as characters.
5. Count newline as a character and a line break.
6. Add one final line if the file does not end with newline.

Commands:
flex 1_count_text.l
gcc lex.yy.c -o 1_count_text
./1_count_text input.txt
*/

%option noyywrap

%{
#include <stdio.h>

int chars = 0;
int words = 0;
int lines = 0;
int hasTextOnLastLine = 0;
%}

%%

[^ \t\r\n]+ {
    words++;
    chars += yyleng;
    hasTextOnLastLine = 1;
}

[ \t\r]+ {
    chars += yyleng;
}

\n {
    chars++;
    lines++;
    hasTextOnLastLine = 0;
}

%%

int main(int argc, char *argv[])
{
    if (argc == 2)
        yyin = fopen(argv[1], "r");

    yylex();

    if (hasTextOnLastLine)
        lines++;

    printf("Characters: %d\n", chars);
    printf("Words: %d\n", words);
    printf("Lines: %d\n", lines);

    return 0;
}
