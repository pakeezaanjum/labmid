/*
Task: Find identifiers and their first line numbers. Ignore comments and whitespace.

Exam approach:
1. Create a .l file and declare an exclusive COMMENT state using %x COMMENT.
2. On /* enter COMMENT state.
3. On */ leave COMMENT state.
4. Ignore // comments until newline.
5. Count newlines even inside block comments.
6. Match identifiers and save only their first line in a map.

Commands:
flex 2_identifiers_without_comments.l
g++ lex.yy.c -o 2_identifiers_without_comments
./2_identifiers_without_comments sample.c
*/

%option noyywrap
%x COMMENT

%{
#include <iostream>
#include <map>
#include <string>
using namespace std;

map<string, int> firstLine;
int line = 1;
%}

IDPAT [A-Za-z_][A-Za-z0-9_]*

%%

"//"[^\n]*          ;

"/*"                { BEGIN(COMMENT); }
<COMMENT>"*/"       { BEGIN(INITIAL); }
<COMMENT>\n         { line++; }
<COMMENT>.          ;

[ \t\r]+            ;
\n                  { line++; }

{IDPAT} {
    if (firstLine.count(yytext) == 0)
        firstLine[yytext] = line;
}

.                   ;

%%

int main(int argc, char *argv[])
{
    if (argc == 2)
        yyin = fopen(argv[1], "r");

    yylex();

    for (auto item : firstLine)
        cout << item.first << " : line " << item.second << endl;

    return 0;
}
