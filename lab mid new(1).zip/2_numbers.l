/*
Task: Lab 2 Task 1: Find integer and decimal constants, including negative values.

Exam approach:
1. Create a .l file.
2. Write a number pattern with optional minus and optional decimal part.
3. Print yytext whenever the pattern matches.
4. Ignore other characters.
5. Run flex, compile with gcc, and scan the source file.

Commands:
flex 2_numbers.l
gcc lex.yy.c -o 2_numbers
./2_numbers sample.c
*/

%option noyywrap

%{
#include <stdio.h>
%}

NUMBER -?[0-9]+(\.[0-9]+)?

%%

{NUMBER}    { printf("%s\n", yytext); }
[ \t\r\n]+  ;
.           ;

%%

int main(int argc, char *argv[])
{
    if (argc == 2)
        yyin = fopen(argv[1], "r");

    yylex();
    return 0;
}
