/*
Task: Predictive parser for statements of the form id = expr;

Exam approach:
1. Create parser.l.
2. Use Flex rules to return ID, NUM and punctuation tokens.
3. Remove left recursion from expr and term.
4. Write one parser function for each grammar non-terminal.
5. Initialize lookahead using yylex().
6. match(token) checks the current token and reads the next token.
7. Compile with flex and g++.

Commands:
flex 3_assignment_parser.l
g++ lex.yy.c -o 3_assignment_parser
./3_assignment_parser input.txt

Grammar after removing left recursion:
stmt   -> ID = expr ;
expr   -> term expr2
expr2  -> + term expr2 | epsilon
term   -> factor term2
term2  -> * factor term2 | epsilon
factor -> ID | NUM | ( expr )
*/

%option noyywrap

%{
#include <iostream>
#include <cstdlib>
#include <cstdio>
using namespace std;

const int T_ID = 350;
const int T_NUM = 360;

int lookahead;
int line = 1;

void match(int);
void error();
void stmt();
void expr();
void expr2();
void term();
void term2();
void factor();
%}

LETTER [A-Za-z_]
DIGIT [0-9]
IDPAT {LETTER}({LETTER}|{DIGIT})*

%%

[ \t\r]+        ;
\n              { line++; }
{IDPAT}         { return T_ID; }
{DIGIT}+        { return T_NUM; }
.               { return yytext[0]; }

%%

int main(int argc, char *argv[])
{
    if (argc == 2)
        yyin = fopen(argv[1], "r");

    lookahead = yylex();
    stmt();

    if (lookahead != 0)
        error();

    cout << "Valid statement" << endl;
    return 0;
}

void match(int token)
{
    if (lookahead == token)
        lookahead = yylex();
    else
        error();
}

void error()
{
    cerr << "Syntax error on line " << line << endl;
    exit(1);
}

void stmt()
{
    match(T_ID);
    match('=');
    expr();
    match(';');
}

void expr()
{
    term();
    expr2();
}

void expr2()
{
    if (lookahead == '+') {
        match('+');
        term();
        expr2();
    }
}

void term()
{
    factor();
    term2();
}

void term2()
{
    if (lookahead == '*') {
        match('*');
        factor();
        term2();
    }
}

void factor()
{
    if (lookahead == T_ID)
        match(T_ID);
    else if (lookahead == T_NUM)
        match(T_NUM);
    else if (lookahead == '(') {
        match('(');
        expr();
        match(')');
    }
    else
        error();
}
