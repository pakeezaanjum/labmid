/*
Task: Combine the expression parser with statement forms from the Lab 3 example.

This simple version supports:
- id = expression ;
- if ( expression ) statement
- for ( expression ; expression ; expression ) statement
- other ;
- blocks { statements }

Exam approach:
1. Start with the Lab 3 expression parser.
2. Add tokens for if and for.
3. Write stmt() as a switch on lookahead.
4. Write separate functions for expression, term and factor.
5. Use match() for every required terminal.

Commands:
flex 3_combined_statements.l
g++ lex.yy.c -o 3_combined_statements
./3_combined_statements input.txt

This is a simple educational combined parser. Each expression in the for header
uses the same expression grammar as assignment expressions.
*/

%option noyywrap

%{
#include <iostream>
#include <cstdlib>
#include <cstdio>
using namespace std;

const int T_ID = 350;
const int T_NUM = 360;
const int T_IF = 310;
const int T_FOR = 311;
const int T_OTHER = 320;

int lookahead;
int line = 1;

void match(int);
void error();
void program();
void block();
void stmts();
void stmt();
void expr();
void expr2();
void term();
void term2();
void factor();
%}

LETTER [A-Za-z_]
DIGIT [0-9]
IDPAT {LETTER}({LETTER}|{DIGIT})*

%%

[ \t\r]+        ;
\n              { line++; }
"if"            { return T_IF; }
"for"           { return T_FOR; }
"other"         { return T_OTHER; }
{IDPAT}         { return T_ID; }
{DIGIT}+        { return T_NUM; }
.               { return yytext[0]; }

%%

int main(int argc, char *argv[])
{
    if (argc == 2)
        yyin = fopen(argv[1], "r");

    lookahead = yylex();
    program();

    if (lookahead != 0)
        error();

    cout << "Valid program" << endl;
    return 0;
}

void match(int token)
{
    if (lookahead == token)
        lookahead = yylex();
    else
        error();
}

void error()
{
    cerr << "Syntax error on line " << line << endl;
    exit(1);
}

void program()
{
    if (lookahead == '{')
        block();
    else
        stmt();
}

void block()
{
    match('{');
    stmts();
    match('}');
}

void stmts()
{
    while (lookahead == T_ID || lookahead == T_IF ||
           lookahead == T_FOR || lookahead == T_OTHER || lookahead == '{') {
        stmt();
    }
}

void stmt()
{
    if (lookahead == T_ID) {
        match(T_ID);
        match('=');
        expr();
        match(';');
    }
    else if (lookahead == T_IF) {
        match(T_IF);
        match('(');
        expr();
        match(')');
        stmt();
    }
    else if (lookahead == T_FOR) {
        match(T_FOR);
        match('(');
        expr();
        match(';');
        expr();
        match(';');
        expr();
        match(')');
        stmt();
    }
    else if (lookahead == T_OTHER) {
        match(T_OTHER);
        match(';');
    }
    else if (lookahead == '{') {
        block();
    }
    else {
        error();
    }
}

void expr()
{
    term();
    expr2();
}

void expr2()
{
    if (lookahead == '+') {
        match('+');
        term();
        expr2();
    }
}

void term()
{
    factor();
    term2();
}

void term2()
{
    if (lookahead == '*') {
        match('*');
        factor();
        term2();
    }
}

void factor()
{
    if (lookahead == T_ID)
        match(T_ID);
    else if (lookahead == T_NUM)
        match(T_NUM);
    else if (lookahead == '(') {
        match('(');
        expr();
        match(')');
    }
    else
        error();
}
