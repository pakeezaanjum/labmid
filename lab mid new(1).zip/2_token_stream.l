/*
Lab 2 Task 3: Convert source code into tokens and ignore // comments.

Exam approach:
1. Make a .l file.
2. Define integer token names in the first section.
3. Write rules for comments and whitespace first.
4. Write keyword rules before the identifier rule.
5. Return a token from every rule that should create a token.
6. In main(), call yylex() in a loop and print the token name.

Commands:
flex 2_token_stream.l
gcc lex.yy.c -o 2_token_stream
./2_token_stream sample.c
*/

%option noyywrap

%{
#include <stdio.h>

#define IF 1
#define ID 2
#define NUM 3
#define LPAREN 4
#define RPAREN 5
#define LT 6
#define GT 7
#define ASSIGN 8
#define PLUS 9
#define MINUS 10
#define STAR 11
#define SLASH 12
#define SEMI 13
#define LBRACE 14
#define RBRACE 15
#define OTHER 16
%}

IDPAT [A-Za-z_][A-Za-z0-9_]*
NUMPAT [0-9]+

%%

"//"[^\n]*      ;
[ \t\r\n]+      ;

"if"            { return IF; }
"("             { return LPAREN; }
")"             { return RPAREN; }
"<"             { return LT; }
">"             { return GT; }
"="             { return ASSIGN; }
"+"             { return PLUS; }
"-"             { return MINUS; }
"*"             { return STAR; }
"/"             { return SLASH; }
";"             { return SEMI; }
"{"             { return LBRACE; }
"}"             { return RBRACE; }

{IDPAT}         { return ID; }
{NUMPAT}        { return NUM; }
.               { return OTHER; }

%%

int main(int argc, char *argv[])
{
    int token;

    if (argc == 2)
        yyin = fopen(argv[1], "r");

    while ((token = yylex()) != 0) {
        switch (token) {
            case IF: printf("<IF>"); break;
            case ID: printf("<ID>"); break;
            case NUM: printf("<NUM>"); break;
            case LPAREN: printf("<LPAREN>"); break;
            case RPAREN: printf("<RPAREN>"); break;
            case LT: printf("<LT>"); break;
            case GT: printf("<GT>"); break;
            case ASSIGN: printf("<ASSIGN>"); break;
            case PLUS: printf("<PLUS>"); break;
            case MINUS: printf("<MINUS>"); break;
            case STAR: printf("<MULTIPLY>"); break;
            case SLASH: printf("<DIVIDE>"); break;
            case SEMI: printf("<SEMICOLON>"); break;
            case LBRACE: printf("<LBRACE>"); break;
            case RBRACE: printf("<RBRACE>"); break;
            case OTHER: printf("<OTHER>"); break;
        }
    }

    printf("\n");
    return 0;
}
