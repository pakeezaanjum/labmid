/*
Task: Build a syntax tree and generate simple intermediate code.

Supported language:
{
    a = 1;
    if (a) {
        b = 2;
    }
}

Exam approach:
1. Create ast.h and predictive.l in the same folder.
2. The lexer returns IF, ID and NUM tokens.
3. Parser functions return syntax tree node pointers.
4. Each grammar production creates the required AST node.
5. main() receives the root node and calls gen().
6. gen() traverses the tree and prints intermediate code.

Commands:
flex predictive.l
g++ lex.yy.c -o predictive
./predictive input.txt
*/

%option noyywrap

%{
#include <iostream>
#include <cstdlib>
#include <cstdio>
#include <string>
#include "ast.h"
using namespace std;

const int T_IF = 310;
const int T_ID = 350;
const int T_NUM = 360;

int lookahead;
int line = 1;

void match(int);
void error();

ast::stmt *program();
ast::stmt *block();
ast::stmt *stmts();
ast::stmt *stmt();

ast::expr *expr();
ast::expr *rp();
ast::expr *factor();
%}

LETTER [A-Za-z_]
ALNUM [A-Za-z0-9_]
DIGIT [0-9]

%%

[ \t\r]+        ;
\n              { line++; }
"if"            { return T_IF; }
{LETTER}{ALNUM}* { return T_ID; }
{DIGIT}+        { return T_NUM; }
.               { return yytext[0]; }

%%

int main(int argc, char *argv[])
{
    if (argc == 2)
        yyin = fopen(argv[1], "r");

    lookahead = yylex();

    ast::stmt *root = program();

    if (lookahead != 0)
        error();

    if (root)
        root->gen();

    return 0;
}

void match(int token)
{
    if (lookahead == token)
        lookahead = yylex();
    else
        error();
}

void error()
{
    cerr << "Syntax error on line " << line << endl;
    exit(1);
}

ast::stmt *program()
{
    return block();
}

ast::stmt *block()
{
    match('{');
    ast::stmt *s = stmts();
    match('}');
    return s;
}

ast::stmt *stmts()
{
    if (lookahead == T_ID || lookahead == T_IF) {
        ast::stmt *left = stmt();
        ast::stmt *right = stmts();
        return new ast::seq(left, right);
    }

    if (lookahead == '{') {
        ast::stmt *left = block();
        ast::stmt *right = stmts();
        return new ast::seq(left, right);
    }

    return NULL;
}

ast::stmt *stmt()
{
    if (lookahead == T_ID) {
        ast::expr *e = expr();
        match(';');
        return new ast::eval(e);
    }

    if (lookahead == T_IF) {
        match(T_IF);
        match('(');
        ast::expr *condition = expr();
        match(')');
        ast::stmt *body = stmt();
        return new ast::if_stmt(condition, body);
    }

    if (lookahead == '{')
        return block();

    error();
    return NULL;
}

ast::expr *expr()
{
    ast::expr *left = factor();
    ast::expr *right = rp();

    if (right == NULL)
        return left;

    return new ast::assign(left, right);
}

ast::expr *rp()
{
    if (lookahead == '=') {
        match('=');
        return expr();
    }

    if (lookahead == ')' || lookahead == ';')
        return NULL;

    error();
    return NULL;
}

ast::expr *factor()
{
    if (lookahead == T_ID) {
        string name(yytext);
        match(T_ID);
        return new ast::id(name);
    }

    if (lookahead == T_NUM) {
        int value = atoi(yytext);
        match(T_NUM);
        return new ast::num(value);
    }

    error();
    return NULL;
}
