/*
Lab 5 syntax tree classes.

Keep ast.h in the same folder as predictive.l.
The parser creates nodes while reading the input.
The gen() functions walk through the tree and print intermediate code.
*/

#ifndef AST_H
#define AST_H

#include <iostream>
#include <string>
#include <sstream>
#include <cstdlib>
using namespace std;

namespace ast {

int label_count = 0;

string new_label()
{
    stringstream out;
    out << ".L" << label_count++;
    return out.str();
}

class node {
};

class stmt : public node {
public:
    virtual void gen() {
    }
};

class expr : public node {
public:
    virtual string str() {
        return "";
    }

    virtual expr *lvalue() {
        cerr << "Invalid left side of assignment" << endl;
        exit(1);
    }

    virtual expr *rvalue() {
        return this;
    }
};

class id : public expr {
public:
    string name;

    id(string n) {
        name = n;
    }

    string str() {
        return name;
    }

    expr *lvalue() {
        return this;
    }
};

class num : public expr {
public:
    int value;

    num(int v) {
        value = v;
    }

    string str() {
        stringstream out;
        out << value;
        return out.str();
    }
};

class assign : public expr {
public:
    expr *left;
    expr *right;

    assign(expr *l, expr *r) {
        left = l;
        right = r;
    }

    expr *rvalue() {
        expr *l = left->lvalue();
        expr *r = right->rvalue();
        cout << l->str() << " = " << r->str() << endl;
        return r;
    }
};

class eval : public stmt {
public:
    expr *value;

    eval(expr *e) {
        value = e;
    }

    void gen() {
        value->rvalue();
    }
};

class seq : public stmt {
public:
    stmt *left;
    stmt *right;

    seq(stmt *l, stmt *r) {
        left = l;
        right = r;
    }

    void gen() {
        if (left)
            left->gen();
        if (right)
            right->gen();
    }
};

class if_stmt : public stmt {
public:
    expr *condition;
    stmt *body;
    string label;

    if_stmt(expr *e, stmt *s) {
        condition = e;
        body = s;
        label = new_label();
    }

    void gen() {
        cout << "ifFalse " << condition->rvalue()->str()
             << " goto " << label << endl;

        if (body)
            body->gen();

        cout << label << " :" << endl;
    }
};

}

#endif
