/*
Task: Find words/identifiers and the line where each first appears.

Exam approach:
1. Create a .l file.
2. Define an identifier pattern.
3. Keep a line counter starting at 1.
4. When an identifier matches, store it only if it is not already in the map.
5. Increase the line counter for every newline.
6. Run flex, compile with g++, then give the source file as input.

Commands:
flex 1_identifiers_first_line.l
g++ lex.yy.c -o 1_identifiers_first_line
./1_identifiers_first_line sample.c
*/

%option noyywrap

%{
#include <iostream>
#include <map>
#include <string>
using namespace std;

map<string, int> firstLine;
int line = 1;
%}

ID [A-Za-z_][A-Za-z0-9_]*

%%

[ \t\r]+        ;
\n              { line++; }

{ID} {
    if (firstLine.count(yytext) == 0) {
        firstLine[yytext] = line;
    }
}

.               ;

%%

int main(int argc, char *argv[])
{
    if (argc == 2)
        yyin = fopen(argv[1], "r");

    yylex();

    for (auto item : firstLine)
        cout << item.first << " : line " << item.second << endl;

    return 0;
}
